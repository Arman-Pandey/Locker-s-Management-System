import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./MainComponent/Home";
import About from "./MainComponent/About";
import Contact from "./MainComponent/Contact";
import Layout from "./UsefullComponent/Layout";

function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="home" element={<Home />} />
        <Route path="about" element={<About />} />
        <Route path="contact" element={<Contact />} />
      </Route>
    </Routes>
  </BrowserRouter>
  );
}

export default App;
