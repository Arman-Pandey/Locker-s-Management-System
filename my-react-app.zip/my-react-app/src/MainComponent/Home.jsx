import NavbarX from "../UsefullComponent/NavbarX";
import one from "../assets/imgs/one.jpeg"
function Home() {
  return (
    <>

<h1>
  home
</h1>
<img src={one} height={200} width={200}/>
    </>
  );
}

export default Home;
