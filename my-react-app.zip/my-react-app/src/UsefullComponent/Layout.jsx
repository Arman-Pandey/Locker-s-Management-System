import { Outlet } from "react-router-dom";
import NavbarX from "./NavbarX";

const Layout = () => {
  return (
    <>
    <NavbarX/>
      <Outlet />
    </>
  )
};

export default Layout;