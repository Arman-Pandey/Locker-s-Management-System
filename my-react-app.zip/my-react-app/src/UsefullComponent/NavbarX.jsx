import {  Link } from "react-router-dom";
function NavbarX() {
  return (
    <>
      <div className="NavBag">
        <div>
          LoGO
        </div>
        <div className="rig-nav">
          <div>
            <ul className="ul-nav">
            <li><Link to="/home">Home</Link></li>
              <li><Link to="/about">About</Link></li>
             <li><Link to="/contact">Contact</Link></li>
            </ul>
          </div>
          <div>LOGIN BUTS</div>
        </div>
      </div>
    </>
  );
}

export default NavbarX;
